﻿using System.Net.Http;

namespace SmartMeter.Test
{
    public class Class1
    {
        HttpClient client = new HttpClient();
        
    }
}
